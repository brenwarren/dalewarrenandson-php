<?php
// For your form to work you need to fill in the following variables
// To get your keys for the reCaptcha, you will need to register on the site
// Go to www.google.com/recaptcha

// This script will only work on PHP version 5.20 and above
// Check with your host that you are running this version

// Secure validation form script by www.bigondesign.co.uk

// Set the below variables

// reCaptcha
$publickey = "Paste your public key here";
$privatekey = "Paste your private key here";

// Website name so you know which site the mail is from
$my_website = "Your company name e.g. Widgets Ltd";

// Your email address for the messages to be sent to
$my_email = "Add your email address here";

// Success message
$success_message = "Your submission has been received and we will contact you shortly";

?>